//: [Previous](@previous)

import Foundation
import UIKit

var greeting = "Hello, playground"

//: [Next](@next)

var a  =   "abocabh"
//Set<Char> ->
// for loop
//for loop

//char.contain()



//char.se -> boc
//substring.app(a)

var b  =  "abcabcde"
//For loop
//if charset.contains
  //find end range
  //





//else
  //append char into charset
var aray : [Int] = []
let queue  = DispatchQueue(label: "com.lavel.serial")
queue.async {
    for i in 0..<10 {
        aray.append(i)
    }
    print(aray)
}

queue.async {
    for i in 10..<20 {
        aray.append(i)
    }
    print(aray)
}
print("Calling node")
